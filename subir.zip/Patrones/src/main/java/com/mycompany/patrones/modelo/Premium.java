/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.patrones.modelo;

/**
 *
 * @author CltControl
 */
public class Premium implements Afiliaciones{

    @Override
    public void asignarTarjeta() {
        System.out.println("proceso para la elaboracion de una tarjeta Premium");
    }
    
}
